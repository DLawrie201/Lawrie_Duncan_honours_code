# CTR-AES_encryption
Implementation of CTR scheme with AES Encryption, for uni cryptography class project

Working program with gui is located on store directory.

NB: This branch is originally a netbeans project dir.
